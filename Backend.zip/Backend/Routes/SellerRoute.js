const express = require('express');
const Product = require('../Schemas/ProductSchema'); // Adjust the path to your Product model
const Order = require('../Schemas/OrderSchema'); // Adjust the path to your Order model
const Review = require('../Schemas/ReviewsSchema'); // Adjust the path to your Review model

const router = express.Router();

// Fetch total products for the seller
router.get('/total-products/:sellerEmail', async (req, res) => {
  try {
    const count = await Product.countDocuments({ sellerEmail: req.params.sellerEmail });
    res.status(200).json({ totalProducts: count });
  } catch (error) {
    console.error('Error fetching total products for the seller:', error);
    res.status(500).json({ error: 'Error fetching total products for the seller' });
  }
});

// Fetch total orders for the seller
router.get('/total-orders/:sellerEmail', async (req, res) => {
  try {
    const orders = await Order.countDocuments({ sellerEmail: req.params.sellerEmail });
    res.status(200).json({ totalOrders: orders });
  } catch (error) {
    console.error('Error fetching total orders for the seller:', error);
    res.status(500).json({ error: 'Error fetching total orders for the seller' });
  }
});

// Fetch total reviews for the seller
router.get('/total-reviews/:sellerEmail', async (req, res) => {
  try {
    const products = await Product.find({ sellerEmail: req.params.sellerEmail });
    const productIds = products.map((product) => product._id);
    
    const reviewsCount = await Review.countDocuments({ productId: { $in: productIds } });
    res.status(200).json({ totalReviews: reviewsCount });
  } catch (error) {
    console.error('Error fetching total reviews for the seller:', error);
    res.status(500).json({ error: 'Error fetching total reviews for the seller' });
  }
});

// Fetch recent reviews for the seller
router.get('/recent-reviews/:sellerEmail', async (req, res) => {
  try {
    const products = await Product.find({ sellerEmail: req.params.sellerEmail });
    const productIds = products.map((product) => product._id);
    
    const reviews = await Review.find({ productId: { $in: productIds } })
      .sort({ createdAt: -1 }) // Sort by most recent
      .limit(5); // Limit to 5 reviews
    
    res.status(200).json(reviews);
  } catch (error) {
    console.error('Error fetching recent reviews for the seller:', error);
    res.status(500).json({ error: 'Error fetching recent reviews for the seller' });
  }
});

module.exports = router;
